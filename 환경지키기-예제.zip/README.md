# 바다에 닿기 전에

쓰레기 종류와 해양 생물 피해를 연결하는 **설치 없는 교육용 웹앱 예제**입니다.

## 실행

`index.html`을 Chrome 또는 Edge에서 열어 주세요. 인터넷 없이도 주요 체험 기능이 동작합니다. 근거 자료 링크를 열 때는 인터넷이 필요합니다.

로컬 서버를 쓰려면 이 폴더에서 실행하세요.

```powershell
python -m http.server 8080 --bind 127.0.0.1
```

브라우저에서 `http://127.0.0.1:8080`을 엽니다. 서버는 `Ctrl+C`로 종료합니다. 파일로 연 페이지와 로컬 서버로 연 페이지의 도감은 서로 다를 수 있습니다.

## 포함된 기능

- 사진 업로드·드래그 앤 드롭·모바일 카메라 입력 (8MB 이하)
- 빨대·비닐봉지·페트병·낚싯줄·담배꽁초 직접 선택
- 피해 설명, 근거 링크, 분리배출·대체 행동 안내
- PNG 카드 저장, 지원되는 모바일 브라우저에서 시스템 공유
- 브라우저 `localStorage`를 이용한 5종 도감 및 기록 삭제
- 3문제 퀴즈, 교육 활동 가이드 및 인쇄
- 모바일 화면과 키보드 탐색 지원

## 체험판의 범위

**AI 사진 인식은 구현되어 있지 않습니다.** 사진은 미리 보기만 하며 자동으로 분류하지 않습니다. 사용자가 직접 종류를 확인·선택합니다. 불확실한 인식 후보를 고르는 화면의 기초로 사용할 수 있습니다.

**실제 피해 사진 대신 직접 작성한 SVG 일러스트를 사용합니다.** 빨대는 실제 구조 사례를 설명하며, 나머지는 알려진 피해 유형 또는 해양 쓰레기 정보를 설명합니다. 각 결과에 근거 자료 링크가 있습니다. 지역별 배출 방법은 거주지 지자체 안내를 확인하세요.

사진은 서버에 업로드하거나 도감에 저장하지 않습니다. 기록에는 쓰레기 종류 ID와 기록 시각만 보관합니다. 브라우저 데이터 삭제 시 기록이 사라집니다. 브라우저 저장이 차단되면 현재 방문 중에만 기록이 유지됩니다. 카메라 입력은 기기·브라우저에 따라 파일 선택창으로 열릴 수 있습니다. 직접 공유를 지원하지 않으면 카드 다운로드로 대체합니다.

## 파일과 수정 위치

- `index.html`: 화면 구성
- `styles.css`: 색상·배치·모바일 스타일
- `app.js`: 쓰레기 데이터(`CASES`), 이미지 미리 보기, 도감, 카드 생성, 퀴즈(`QUESTIONS`)

AI를 붙일 때는 별도 서버에서 이미지 분류 API를 호출하고 `straw`, `bag`, `bottle`, `line`, `cigarette` 중 후보 ID와 신뢰도를 반환하도록 확장하세요. 반환된 후보는 사용자가 최종 확인하게 하고, 해당 종류가 없을 때도 직접 선택하도록 유지하세요. API 비밀 키는 프런트엔드에 넣지 않습니다. 실제 피해 이미지를 추가할 때는 이용 허락·출처와 수업 연령에 맞는 노출 방식을 확인하세요.

## 참고 자료

- [Texas A&M: 바다거북의 코에 박힌 빨대 구조 사례](https://storiesdev.marcomm.tamu.edu/news/2015/11/18/the-turtle-with-a-straw-in-its-nose-the-story-behind-the-viral-video/)
- [NOAA Fisheries: 바다거북을 돕는 방법](https://www.fisheries.noaa.gov/feature-story/what-can-you-do-help-sea-turtles)
- [NOAA Marine Debris: 플라스틱](https://marinedebris.noaa.gov/what-marine-debris/plastic)
- [NOAA Fisheries: 해양 생물 얽힘 피해](https://www.fisheries.noaa.gov/insight/entanglement-marine-life-risks-and-response)
- [NOAA: 담배 필터와 해양 쓰레기](https://oceanservice.noaa.gov/facts/most-common-ocean-litter.html)
- [한국소비자원: 재질별 분리배출](https://www.kca.go.kr/smartconsumer/sub.do?menukey=7740)
